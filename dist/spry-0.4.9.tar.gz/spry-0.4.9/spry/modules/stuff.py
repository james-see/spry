# -*- coding: utf-8 -*-


"""spry.stuff: stuff module within the bootstrap package."""


class Stuff(object):
    pass
