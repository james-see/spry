SPRY

.. image:: https://img.shields.io/pypi/v/spry.svg
    :target: https://pypi.python.org/pypi/spry

social media intelligence from the terminal

this is a very early beta release

the only thing that works is instagram

run via spry [username]
